package model;

/**
 * Score: de score die een cursist krijgt.
 * 
 * @author Keanu en Gil
 */

 //Objecten aanmaken
public class Score {
    private String voornaam;
    private String achternaam;
    private double score;

    public String getVoornaam() {
        return voornaam;
    }

    public void setVoornaam(String voornaam) {
        this.voornaam = voornaam;
    }

    public String getAchternaam() {
        return achternaam;
    }

    public void setAchternaam(String achternaam) {
        this.achternaam = achternaam;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }
    
    
    
}
