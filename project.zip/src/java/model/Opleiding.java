/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Davino
 */
public class Opleiding {

    private int opleidingID;
    private String naam;

    public int getOpleidingID() {
        return opleidingID;
    }

    public void setOpleidingID(int opleidingID) {
        this.opleidingID = opleidingID;
    }

    public String getNaam() {
        return naam;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }

}
