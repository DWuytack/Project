/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author dw018
 */
public class Lesnr {
    private int lesID;
    private int lesnr;

    public int getLesID() {
        return lesID;
    }

    public void setLesID(int lesID) {
        this.lesID = lesID;
    }

    public int getLesnr() {
        return lesnr;
    }

    public void setLesnr(int lesnr) {
        this.lesnr = lesnr;
    }

  
   
}
