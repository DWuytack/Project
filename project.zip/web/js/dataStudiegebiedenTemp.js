var data = {
    opleiding: {
        gebied1: [
            {
                value: "opleiding1a",
                view: "opleiding1"
            },
            {
                value: "opleiding2a",
                view: "opleiding2"
            },
            {
                value: "opleiding3a",
                view: "opleiding3"
            },
            {
                value: "opleiding4a",
                view: "opleiding4"
            }
        ],
        gebied2: [{
                value: "opleiding1b",
                view: "opleiding1b"
            },
            {
                value: "opleiding2b",
                view: "opleiding2b"
            }
        ]

    },
    module: {
        opleiding1a: [
            {
                value: "module1a",
                view: "module1"
            },
            {
                value: "module2a",
                view: "module2"
            },
            {
                value: "module3a",
                view: "module3"
            },
            {
                value: "module4a",
                view: "module4"
            }
        ],
        opleiding2a: [
            {
                value: "module1b",
                view: "module1b"
            },
            {
                value: "module2b",
                view: "module2b"
            }
        ],
        opleiding1b: [
            {
                value: "module1a",
                view: "module1"
            },
            {
                value: "module2a",
                view: "module2"
            },
            {
                value: "module3a",
                view: "module3"
            },
            {
                value: "module4a",
                view: "module4"
            }
        ],
        opleiding2b: [
            {
                value: "module1b",
                view2: "module1b"
            },
            {
                value: "module2b",
                view: "module2b"
            }
        ]
    },
    doelstelling: {
        module1a: [
            {
                value: "doelstelling1a",
                view: "doelstelling1"
            },
            {
                value: "doelstelling2a",
                view: "doelstelling2"
            },
            {
                value: "doelstelling3a",
                view: "doelstelling3"
            },
            {
                value: "doelstelling4a",
                view: "doelstelling4"
            }
        ],
        module2a: [
            {
                value: "doelstelling1b",
                view: "doelstelling1b"
            },
            {
                value: "doelstelling2b",
                view: "doelstelling2b"
            }
        ],
        module1b: [
            {
                value: "doelstelling1a",
                view: "doelstelling1"
            },
            {
                value: "doelstelling2a",
                view: "doelstelling2"
            },
            {
                value: "doelstelling3a",
                view: "doelstelling3"
            },
            {
                value: "doelstelling4a",
                view: "doelstelling4"
            }
        ],
        module2b: [
            {
                value: "doelstelling1b",
                view2: "doelstelling1b"
            },
            {
                value: "doelstelling2b",
                view: "doelstelling2b"
            }
        ]
    }

};
console.log(data);
